// ==================== S.JARVIS - Iron Man Style AI Assistant ====================

class Jarvis {
    constructor() {
        this.geminiKey = localStorage.getItem('geminiKey') || '';
        this.openaiKey = localStorage.getItem('openaiKey') || '';
        this.aiModel = localStorage.getItem('aiModel') || 'gemini';
        this.voiceSpeed = parseFloat(localStorage.getItem('voiceSpeed') || '1.0');
        this.autoSpeak = localStorage.getItem('autoSpeak') !== 'false';
        this.theme = localStorage.getItem('theme') || 'purple';
        this.isListening = false;
        this.recognition = null;

        this.init();
    }

    init() {
        // Loading screen
        setTimeout(() => {
            document.getElementById('loading-screen').classList.add('hidden');
            document.getElementById('app').classList.remove('hidden');
            this.applyTheme(this.theme);
            this.speak("S Jarvis online ho gaya. Saare systems theek chal rahe hain. Aapki kya madad karun?");
        }, 2200);

        this.bindEvents();
        this.initSpeechRecognition();
        this.loadSettings();
    }

    bindEvents() {
        // Send message
        document.getElementById('send-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('user-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });

        // Mic
        document.getElementById('mic-btn').addEventListener('click', () => this.toggleListening());

        // Settings
        document.getElementById('settings-btn').addEventListener('click', () => {
            document.getElementById('settings-panel').classList.remove('hidden');
        });
        document.getElementById('close-settings').addEventListener('click', () => {
            document.getElementById('settings-panel').classList.add('hidden');
        });
        document.getElementById('save-settings').addEventListener('click', () => this.saveSettings());

        // Clear chat
        document.getElementById('clear-btn').addEventListener('click', () => this.clearChat());

        // Voice speed slider
        document.getElementById('voice-speed').addEventListener('input', (e) => {
            document.getElementById('speed-value').textContent = e.target.value + 'x';
        });

        // Theme buttons
        document.querySelectorAll('.theme-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });
    }

    loadSettings() {
        document.getElementById('gemini-key').value = this.geminiKey;
        document.getElementById('openai-key').value = this.openaiKey;
        document.getElementById('ai-model').value = this.aiModel;
        document.getElementById('voice-speed').value = this.voiceSpeed;
        document.getElementById('speed-value').textContent = this.voiceSpeed + 'x';
        document.getElementById('auto-speak').checked = this.autoSpeak;

        document.querySelectorAll('.theme-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === this.theme);
        });
    }

    saveSettings() {
        this.geminiKey = document.getElementById('gemini-key').value.trim();
        this.openaiKey = document.getElementById('openai-key').value.trim();
        this.aiModel = document.getElementById('ai-model').value;
        this.voiceSpeed = parseFloat(document.getElementById('voice-speed').value);
        this.autoSpeak = document.getElementById('auto-speak').checked;
        this.theme = document.querySelector('.theme-btn.active')?.dataset.theme || 'purple';

        localStorage.setItem('geminiKey', this.geminiKey);
        localStorage.setItem('openaiKey', this.openaiKey);
        localStorage.setItem('aiModel', this.aiModel);
        localStorage.setItem('voiceSpeed', this.voiceSpeed);
        localStorage.setItem('autoSpeak', this.autoSpeak);
        localStorage.setItem('theme', this.theme);

        this.applyTheme(this.theme);
        document.getElementById('settings-panel').classList.add('hidden');
        this.addSystemMessage('Settings successfully save ho gaye.');
        this.speak('Settings update ho gaye.');
    }

    applyTheme(theme) {
        document.body.classList.remove('theme-blue', 'theme-red');
        if (theme === 'blue') document.body.classList.add('theme-blue');
        if (theme === 'red') document.body.classList.add('theme-red');
    }

    // ========== CHAT ==========
    async sendMessage() {
        const input = document.getElementById('user-input');
        const text = input.value.trim();
        if (!text) return;

        input.value = '';
        this.addMessage(text, 'user');
        this.showTyping();

        try {
            let reply;
            if (this.aiModel === 'gemini' && this.geminiKey) {
                reply = await this.callGemini(text);
            } else if (this.aiModel === 'openai' && this.openaiKey) {
                reply = await this.callOpenAI(text);
            } else {
                // Fallback demo responses when no API key
                reply = this.getDemoResponse(text);
            }

            this.hideTyping();
            this.addMessage(reply, 'assistant');
            if (this.autoSpeak) this.speak(reply);
        } catch (err) {
            this.hideTyping();
            const errorMsg = `Error aa gaya: ${err.message}. Settings me jaake apni API key check karo.`;
            this.addMessage(errorMsg, 'assistant');
            this.speak('Kuch error aa gaya. Please apni API key check kar lo Settings me.');
        }
    }

    async callGemini(prompt) {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${this.geminiKey}`;
        
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: `Tum S.JARVIS ho, Iron Man ke JARVIS jaisa advanced AI assistant. Tum highly intelligent, witty, precise aur loyal ho. Hamesha Hinglish me baat karo (Hindi + English mix). Simple, clear aur thoda smart style me jawab do. User ka sawal: ${prompt}`
                    }]
                }],
                generationConfig: {
                    temperature: 0.7,
                    maxOutputTokens: 1024
                }
            })
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.error?.message || 'Gemini API error');
        }

        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response received.';
    }

    async callOpenAI(prompt) {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.openaiKey}`
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                messages: [
                    {
                        role: 'system',
                        content: 'Tum S.JARVIS ho, Iron Man ke JARVIS jaisa advanced AI assistant. Tum highly intelligent, witty, precise aur loyal ho. Hamesha Hinglish me baat karo (Hindi + English mix). Simple, clear aur thoda smart style me jawab do.'
                    },
                    { role: 'user', content: prompt }
                ],
                temperature: 0.7,
                max_tokens: 1024
            })
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.error?.message || 'OpenAI API error');
        }

        const data = await response.json();
        return data.choices?.[0]?.message?.content || 'No response received.';
    }

    getDemoResponse(text) {
        const lower = text.toLowerCase();
        
        if (lower.includes('hello') || lower.includes('hi') || lower.includes('namaste') || lower.includes('hey')) {
            return "Namaste! S.JARVIS ready hai. Saare systems theek chal rahe hain. Boliye, kya madad chahiye?";
        }
        if (lower.includes('who are you') || lower.includes('kaun ho') || lower.includes('tum kaun')) {
            return "Main S.JARVIS hoon — Stark Intelligence System. Iron Man ke original JARVIS jaisa advanced AI assistant, ab modern features ke saath.";
        }
        if (lower.includes('time') || lower.includes('samay') || lower.includes('kitne baje')) {
            return `Abhi time ho raha hai ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}.`;
        }
        if (lower.includes('date') || lower.includes('tarikh') || lower.includes('aaj ka din')) {
            return `Aaj ki date hai ${new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`;
        }
        if (lower.includes('weather') || lower.includes('mausam')) {
            return "Live weather ke liye API chahiye. Abhi demo mode me hoon. Full power chahiye to Settings me Gemini ya ChatGPT API key daal do.";
        }
        if (lower.includes('api') || lower.includes('key') || lower.includes('setting')) {
            return "Full AI power unlock karne ke liye Settings me jaake Gemini API key ya OpenAI (ChatGPT) API key daalo. Gemini key free me mil jaati hai Google AI Studio se.";
        }
        if (lower.includes('thank') || lower.includes('shukriya') || lower.includes('dhanyavad')) {
            return "Bilkul welcome! Hamesha madad ke liye ready rehta hoon.";
        }
        if (lower.includes('bye') || lower.includes('goodbye') || lower.includes('alvida') || lower.includes('chalta')) {
            return "Theek hai, systems standby mode me daal raha hoon. Phir milte hain. S.JARVIS standing by.";
        }

        return `Samajh gaya aapka sawal "${text}" ke baare me. Abhi demo mode me hoon. Real intelligent answers chahiye to Settings me API key daal do — Gemini ya ChatGPT. Uske baad main proper detailed jawab dunga.`;
    }

    addMessage(text, type) {
        const container = document.getElementById('chat-container');
        const msg = document.createElement('div');
        msg.className = `message ${type}`;
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        if (type === 'assistant') {
            content.innerHTML = `<strong>S.JARVIS</strong><br>${this.formatText(text)}`;
        } else {
            content.textContent = text;
        }
        
        msg.appendChild(content);
        container.appendChild(msg);
        container.scrollTop = container.scrollHeight;
    }

    addSystemMessage(text) {
        const container = document.getElementById('chat-container');
        const msg = document.createElement('div');
        msg.className = 'message system';
        msg.innerHTML = `<div class="message-content">${text}</div>`;
        container.appendChild(msg);
        container.scrollTop = container.scrollHeight;
    }

    formatText(text) {
        // Simple markdown-like formatting
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');
    }

    showTyping() {
        const container = document.getElementById('chat-container');
        const typing = document.createElement('div');
        typing.className = 'message assistant';
        typing.id = 'typing-indicator';
        typing.innerHTML = `
            <div class="message-content typing-indicator">
                <span></span><span></span><span></span>
            </div>
        `;
        container.appendChild(typing);
        container.scrollTop = container.scrollHeight;
    }

    hideTyping() {
        const typing = document.getElementById('typing-indicator');
        if (typing) typing.remove();
    }

    clearChat() {
        const container = document.getElementById('chat-container');
        container.innerHTML = `
            <div class="message system">
                <div class="message-content">
                    <strong>S.JARVIS</strong> online ho gaya. Saare systems theek chal rahe hain. Boliye, kya madad chahiye?
                </div>
            </div>
        `;
        this.speak('Chat history clear ho gaya. Naye sawalon ke liye ready hoon.');
    }

    // ========== VOICE ==========
    speak(text) {
        if (!window.speechSynthesis) return;

        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        
        // Lovely natural female voice priority list
        const voices = window.speechSynthesis.getVoices();
        
        // Priority order for soft, lovely female voices
        const preferredVoices = [
            // Best quality female voices
            'Google UK English Female',
            'Microsoft Zira - English (United States)',
            'Microsoft Zira Desktop - English (United States)',
            'Samantha',
            'Karen',
            'Moira',
            'Tessa',
            'Veena',
            'Google US English',
            'Microsoft Aria Online (Natural) - English (United States)',
            'Microsoft Jenny Online (Natural) - English (United States)',
            'Microsoft Sonia Online (Natural) - English (United Kingdom)',
            // Fallback patterns
            'female',
            'zira',
            'samantha',
            'aria',
            'jenny',
            'sonia'
        ];

        let selectedVoice = null;

        // First try exact preferred names
        for (const name of preferredVoices) {
            selectedVoice = voices.find(v => 
                v.name.toLowerCase() === name.toLowerCase() || 
                v.name.toLowerCase().includes(name.toLowerCase())
            );
            if (selectedVoice) break;
        }

        // If still not found, find any English female-sounding voice
        if (!selectedVoice) {
            selectedVoice = voices.find(v => 
                v.lang.startsWith('en') && 
                (v.name.toLowerCase().includes('female') || 
                 v.name.toLowerCase().includes('woman') ||
                 v.name.toLowerCase().includes('zira') ||
                 v.name.toLowerCase().includes('samantha') ||
                 v.name.toLowerCase().includes('karen') ||
                 v.name.toLowerCase().includes('moira'))
            );
        }

        // Last fallback - any English voice
        if (!selectedVoice) {
            selectedVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
        }

        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
        
        // Soft & lovely settings
        utterance.rate = this.voiceSpeed;   // 1.0x default
        utterance.pitch = 1.15;             // Slightly higher = softer feminine tone
        utterance.volume = 1;
        
        window.speechSynthesis.speak(utterance);
    }

    initSpeechRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            document.getElementById('mic-btn').style.opacity = '0.4';
            return;
        }

        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'hi-IN'; // Hinglish / Hindi better support

        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            document.getElementById('user-input').value = transcript;
            this.sendMessage();
        };

        this.recognition.onend = () => {
            this.isListening = false;
            document.getElementById('mic-btn').classList.remove('listening');
        };

        this.recognition.onerror = () => {
            this.isListening = false;
            document.getElementById('mic-btn').classList.remove('listening');
        };
    }

    toggleListening() {
        if (!this.recognition) {
            this.addSystemMessage('Is browser me speech recognition support nahi hai.');
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
            this.isListening = false;
            document.getElementById('mic-btn').classList.remove('listening');
        } else {
            this.recognition.start();
            this.isListening = true;
            document.getElementById('mic-btn').classList.add('listening');
        }
    }
}

// Load voices properly (important for female voice selection)
let voicesLoaded = false;

function loadVoices() {
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
        voicesLoaded = true;
    }
}

if (window.speechSynthesis) {
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
}

// Start the app
document.addEventListener('DOMContentLoaded', () => {
    // Small delay to ensure voices are loaded
    setTimeout(() => {
        window.jarvis = new Jarvis();
    }, 300);
});
