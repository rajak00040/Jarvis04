# S.JARVIS — Iron Man Style AI Assistant

Purple Arc Reactor themed AI assistant with female voice, Gemini + ChatGPT support.

## Features
- Premium Purple Arc Reactor theme + 2 more themes
- Female voice (1x speed, adjustable)
- Gemini AI + ChatGPT (OpenAI) dual API support
- Voice input (mic)
- Auto-speak responses
- Clean Iron Man inspired UI
- “S” logo

## How to Use

### Method 1: Direct Open (Easiest)
1. Folder `jarvis-assistant` ko apne phone me copy karo
2. `index.html` file ko Chrome browser se open karo
3. Settings me jaake API key daalo

### Method 2: Local Server (Recommended)
Phone pe:
- **HTTP Server** ya **Simple HTTP Server** app install karo
- Folder select karke server start karo
- Browser me `http://localhost:8080` open karo

Computer pe:
```bash
cd jarvis-assistant
python -m http.server 8080
```
Phir browser me `http://localhost:8080` open karo.

## API Keys Kaise Lein

### Gemini AI (Free)
1. https://aistudio.google.com/app/apikey pe jao
2. “Create API Key” click karo
3. Key copy karke Settings me paste karo

### ChatGPT (OpenAI)
1. https://platform.openai.com/api-keys pe jao
2. New secret key banao
3. Settings me paste karo

## Notes
- Pehli baar voice ke liye browser permission dena padega
- Offline me bhi basic demo responses kaam karte hain
- Best experience Chrome / Edge me milta hai
